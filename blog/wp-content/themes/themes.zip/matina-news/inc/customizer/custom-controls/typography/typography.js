/**
 * Custom scripts for Typography Control
 *
 * @package Matina News
 */

jQuery(document).ready(function($){

    "use-strict";
    $('.customize-control-select2').select2({
        allowClear: true
    });
    
});